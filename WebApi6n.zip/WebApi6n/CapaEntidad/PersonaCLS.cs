﻿namespace CapaEntidad
{
    public class PersonaCLS
    {
        public int iidpersona { get; set; }
        public string nombrecompleto { get; set; }
        public string correo { get; set;}
        public string fechanacimientocadena { get; set;}

    }
}
