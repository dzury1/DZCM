﻿using AutoMapper;
using WebApi6n.Dto;
using WebApi6n.Models;

namespace WebApi6n.WebApiMapper
{
    public class WebApisMapper : Profile
    {
        public WebApisMapper()
        {
            CreateMap<UsuarioDZ, UsuarioDZDto>().ReverseMap();
            CreateMap<UsuarioDZ, UsuarioLoginDZDto>().ReverseMap();
            CreateMap<UsuarioDZ, UsuarioLoginRespuestaDZDto>().ReverseMap();
            CreateMap<UsuarioDZ, UsuarioRegistroDZDto>().ReverseMap(); 
        }
    }
}
