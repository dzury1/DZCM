﻿using Microsoft.EntityFrameworkCore;
using WebApi6n.Models;


namespace WebApi6n.Data
{
    public class ApplicationDbContext : DbContext
    {
       public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) 
       { 
        
       }

       //Agregar los modelos aqui
            public virtual DbSet<UsuarioDZ> UsuarioDZs { get; set; }  //UsuarioDZ


    }
}
