﻿using System;
using System.Collections.Generic;

namespace WebApi6n.Models
{
    public partial class Dzz
    {
        public int? IdName { get; set; }
        public string? Uno { get; set; }
        public string? Dos { get; set; }
    }
}
