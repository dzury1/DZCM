﻿using System;
using System.Collections.Generic;

namespace WebApi6n.Models
{
    public partial class Pagina
    {
        public Pagina()
        {
            PaginaTipoUsuarios = new HashSet<PaginaTipoUsuario>();
        }

        public int Iidpagina { get; set; }
        public string? Mensaje { get; set; }
        public string? Accion { get; set; }
        public int? Bhabilitado { get; set; }
        public string? Controlador { get; set; }

        public virtual ICollection<PaginaTipoUsuario> PaginaTipoUsuarios { get; set; }
    }
}
