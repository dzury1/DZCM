﻿using WebApi6n.Models;

namespace WebApi6n.Dto
{
    public class UsuarioLoginRespuestaDZDto
    {

        public UsuarioDZ Usuario { get; set; }
        public string? Token { get; set; }

    }
}
