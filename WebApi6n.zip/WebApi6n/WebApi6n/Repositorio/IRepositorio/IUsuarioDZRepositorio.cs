﻿using WebApi6n.Dto;
using WebApi6n.Models;

namespace WebApi6n.Repositorio.IRepositorio
{
    public interface IUsuarioDZRepositorio
    {

        ICollection<UsuarioDZ> GetUsuarios();
        ICollection<UsuarioDZ> GetUsuariosSP();
        UsuarioDZ GetUsuario(int usuarioId);
        bool IsUniqueUser(string usuario);
        Task<UsuarioLoginRespuestaDZDto> Login(UsuarioLoginDZDto usuarioLoginDZDto);
        Task<UsuarioDZ> Registro(UsuarioRegistroDZDto usuarioRegistroDZDto);


    }
}

