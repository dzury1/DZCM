﻿using System.Security.Cryptography;
using WebApi6n.Dto;
using WebApi6n.Models;
using WebApi6n.Repositorio.IRepositorio;
using Microsoft.EntityFrameworkCore;
//using static System.Runtime.InteropServices.Java.JavaScript.JSType;
using System.Data;
using System.Text;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using WebApi6n.Data;






namespace WebApi6n.Repositorio
{
    public class UsuarioDZRepositorio : IUsuarioDZRepositorio
    {

        // ApplicationDbContext 
        //private readonly BdveterinariaContext _bd;
        private readonly ApplicationDbContext _bd;
        private string ClaveSecreta;

        //public UsuarioDZRepositorio(BdveterinariaContext bd, IConfiguration config)
        public UsuarioDZRepositorio(ApplicationDbContext bd, IConfiguration config)
        {
            _bd = bd;
            ClaveSecreta = config.GetValue<string>("ApiSettings:Secreta");
            string ClaveSecretaD;
            ClaveSecretaD = ClaveSecreta;

        }


        public UsuarioDZ GetUsuario(int usuarioId)
        {
            return _bd.UsuarioDZs.FirstOrDefault(c => c.Id == usuarioId);

        }

        public ICollection<UsuarioDZ> GetUsuarios()
        {
            return _bd.UsuarioDZs.OrderBy(c => c.Nombre).ToList();
        }

        public ICollection<UsuarioDZ> GetUsuariosSP()
        {
            return _bd.UsuarioDZs.OrderBy(c => c.Nombre).ToList();
        }

        public bool IsUniqueUser(string usuario)
        {
            var usuariobd = _bd.UsuarioDZs.FirstOrDefault(c => c.NombreUsuario == usuario);
            if (usuariobd != null)
            {
                return true;
            }


            return false;

        }



        public async Task<UsuarioLoginRespuestaDZDto> Login(UsuarioLoginDZDto usuarioLoginDZDto)
        {
            var passwordEncriptado = obtenermd5(usuarioLoginDZDto.Password);

            //lo quite porque el password guardado no esta encriptado solo para pruebas
            /*var usuarioDZ = _bd.UsuarioDZs.FirstOrDefault(
                u => u.NombreUsuario.ToLower() == usuarioLoginDZDto.NombreUsuario.ToLower()
                && u.Password == passwordEncriptado);*/

            var usuarioDZ = _bd.UsuarioDZs.FirstOrDefault(
                u => u.NombreUsuario.ToLower() == usuarioLoginDZDto.NombreUsuario.ToLower());
               


            //Validamos si el usuario no existe con la combinacion de usuario y contraseña correcta
            if (usuarioDZ == null)
            {
                //UsuarioLoginRespuestaDZDto usuarioLoginRespuestaDZDto = new UsuarioLoginRespuestaDZDto()
                UsuarioLoginRespuestaDZDto usuarioLoginRespuestaDZDtoA = new UsuarioLoginRespuestaDZDto()
                //return new UsuarioLoginRespuestaDZDto()
                {
                    Token = "",
                    Usuario = null
                };
                return usuarioLoginRespuestaDZDtoA;
            }

            //Aqui existe el login entonces podemos procesar el login

            var manejadorToken = new JwtSecurityTokenHandler();


            //quitar use dz solo para prueba
            /*string ClaveSecretaC;
            ClaveSecretaC = "Palabra secreta para validar los tokens, cambiar por una personalizada";

            IConfigurationBuilder builder1 = new ConfigurationBuilder();
            builder1.AddJsonFile(Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json"));
            var root = builder1.Build();
            string ClaveSecretaB;
            ClaveSecretaB = root.GetConnectionString("ApiSettings:Secreta");*/




            var key = Encoding.ASCII.GetBytes(ClaveSecreta);
            var TokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, usuarioDZ.NombreUsuario.ToString())
                    //new Claim(ClaimTypes.Role, usuarioDZ.Role)
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = manejadorToken.CreateToken(TokenDescriptor);

            UsuarioDZ nwusuario = new UsuarioDZ()
            {

                NombreUsuario = usuarioDZ.NombreUsuario,
                Password = "Si existe",
                Nombre = usuarioDZ.Nombre,
                Role = "Ninguno"
            };

            UsuarioLoginRespuestaDZDto usuarioLoginRespuestaDZDto = new UsuarioLoginRespuestaDZDto()            
            {
                Token = manejadorToken.WriteToken(token),
                Usuario = nwusuario //anterior //usuarioDZ
            };

            return usuarioLoginRespuestaDZDto;



        }



        public async Task<UsuarioDZ> Registro(UsuarioRegistroDZDto usuarioRegistroDZDto)  
        {
            
            var passwordEncriptado = obtenermd5(usuarioRegistroDZDto.Password);
            UsuarioDZ usuarioDZ = new UsuarioDZ()
            {
                NombreUsuario = usuarioRegistroDZDto.NombreUsuario,
                Password = usuarioRegistroDZDto.Password,
                Nombre = usuarioRegistroDZDto.Nombre,
                Role = usuarioRegistroDZDto.Role

            };

            //_bd.Add(usuarioRegistroDZDto);

            _bd.Add(usuarioDZ);

            await _bd.SaveChangesAsync();
            return usuarioDZ;
        }

        //Método para encriptar contraseña con MD5 se usa tanto en el Acceso como en el Registro
        public static string obtenermd5(string valor)
        {
            //anterior obsoleto
            //MD5CryptoServiceProvider x = new ()

            //using (var md5 = MD5.Create())
            var x = MD5.Create();
            byte[] data = System.Text.Encoding.UTF8.GetBytes(valor);
            data = x.ComputeHash(data);
            string resp = "";
            for (int i = 0; i < data.Length; i++)
                resp += data[i].ToString("x2").ToLower();

            return resp;
           
        }




        /*
         
                    using (var md5 = MD5.Create())
                {
                    var result = md5.ComputeHash(Encoding.ASCII.GetBytes(input));
                    return Encoding.ASCII.GetString(result);
                }
         
         */



    }
}
