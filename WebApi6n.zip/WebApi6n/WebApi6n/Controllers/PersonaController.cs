﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using CapaEntidad;
using System.ComponentModel;
using WebApi6n.Models;


//regresar cuando empiece a modificar o hacer pruebas dz

/*namespace WebApi6n.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonaController : ControllerBase
    {
        [HttpGet]
        public List<PersonaCLS> ListarPersonas()
        {
            List<PersonaCLS> lista = new List<PersonaCLS>();
            try 
            {
                using(db_aa50c8_bdveterinariaContext bd = new db_aa50c8_bdveterinariaContext())
                {
                    lista = (from Persona in bd.Personas
                            where Persona.Bhabilitado == 1
                            select new PersonaCLS
                            {
                                        iidpersona = Persona.Iidpersona,
                                        nombrecompleto = Persona.Nombre + " " + Persona.Appaterno + " " + Persona.Apmaterno,
                                        correo = Persona.Correo,
                                        fechanacimientocadena = Persona.Fechanacimiento == null ? ""
                                        : Persona.Fechanacimiento.Value.ToString("dd/MM/yyyy")
                            }).ToList();
                    return lista;

                }
            }
            catch 
            { 
                return lista; 
            }


        }

        [HttpGet("{nombrecompleto}")]
        public List<PersonaCLS> ListarPersonas(string nombrecompleto)
        {
            List<PersonaCLS> lista = new List<PersonaCLS>();
            try
            {
                using (db_aa50c8_bdveterinariaContext bd = new db_aa50c8_bdveterinariaContext())
                {
                    lista = (from Persona in bd.Personas
                             where Persona.Bhabilitado == 1
                             && (Persona.Nombre + " " + Persona.Appaterno + " " + Persona.Appaterno).Contains(nombrecompleto)
                             select new PersonaCLS
                             {
                                 iidpersona = Persona.Iidpersona,
                                 nombrecompleto = Persona.Nombre + " " + Persona.Appaterno + " " + Persona.Apmaterno,
                                 correo = Persona.Correo,
                                 fechanacimientocadena = Persona.Fechanacimiento == null ? ""
                                         : Persona.Fechanacimiento.Value.ToString("dd/MM/yyyy")
                             }).ToList();
                    return lista;

                }
            }
            catch
            {
                return lista;
            }


        }


    }
}*/
